package fr.mds.pockemontcg.Service.retrofit;

import retrofit2.Retrofit;
import  retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitClient {

    //singleton
    private  static PokeService pokeService;
    public static  PokeService getPokeService() {

        if (pokeService == null) {
            //instanceservice
            Retrofit retrofit = new Retrofit.Builder()
                    .baseUrl("https://api.pokemontcg.io/v1/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();

            //create
            pokeService = retrofit.create(PokeService.class);
        }
        return pokeService;
    }
}
