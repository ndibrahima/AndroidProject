package fr.mds.pockemontcg.Activity;

import androidx.appcompat.app.AppCompatActivity;
import fr.mds.pockemontcg.Adapter.CardAdapter;
import fr.mds.pockemontcg.R;
import fr.mds.pockemontcg.Service.retrofit.DataContainer;
import fr.mds.pockemontcg.Service.retrofit.RetrofitClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.os.Bundle;
import android.util.Log;
import java.util.ArrayList;
import java.util.List;
import fr.mds.pockemontcg.R;
import fr.mds.pockemontcg.Adapter.CardAdapter;
import fr.mds.pockemontcg.Model.Card;
import fr.mds.pockemontcg.Service.retrofit.DataContainer;
import fr.mds.pockemontcg.Service.retrofit.RetrofitClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static final String TAG="PokemonTCG";
    private RecyclerView rv_main_cards;
    private List<Card> cards = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rv_main_cards = findViewById(R.id.rv_main_cards);
        CardAdapter cardsAdapter = new CardAdapter(cards);
        rv_main_cards.setAdapter(cardsAdapter);
        rv_main_cards.setLayoutManager(new LinearLayoutManager(this));


        Call<DataContainer> getCardsCall= RetrofitClient.getPokeService().getCards();

        getCardsCall.enqueue(new Callback<DataContainer>() {
            @Override
            public void onResponse(Call<DataContainer> call, Response<DataContainer> response) {
                Log.d(TAG, "MainActivity - getCardsCall - onResponse");
                Log.d(TAG, response.code() + "");
                Log.d(TAG, response.body().toString());
                cards.clear();
                cards.addAll(response.body().getCards());
                cardsAdapter.notifyDataSetChanged();
            }
            @Override
            public void onFailure(Call<DataContainer> call, Throwable t) {
                Log.d(TAG, "MainActivity - getCardsCall - onFailure");
                Log.d(TAG,t.getMessage());
            }
        });
    }
}
