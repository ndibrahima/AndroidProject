package fr.mds.pockemontcg.Adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.Hashtable;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import fr.mds.pockemontcg.Model.Card;
import fr.mds.pockemontcg.R;
import fr.mds.pockemontcg.ViewHolder.CardViewHolder;

public class CardAdapter extends RecyclerView.Adapter<CardViewHolder> {

    private List<Card> cards;

    public CardAdapter(List<Card> cards) {
    this.cards =cards;
}

    @NonNull
    @Override
    public CardViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int ViewType) {
        View mainViewHolder = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_card, parent, false);
        CardViewHolder cardViewHolder = new CardViewHolder(mainViewHolder);
        return  cardViewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull CardViewHolder holder, int position) {

       Card card = cards.get(position);
        TextView tv_item_card_name = holder.getTv_item_card_name();
        tv_item_card_name.setText(card.getName());

       // ImageView iv_item_card_name = holder.getTv_item_card_image();
       // Picasso.get().load(card.getImagePath().into(iv_item_card_imqge));

    }

    @Override
    public  int getItemCount() {
        return  cards.size();
    }

}
