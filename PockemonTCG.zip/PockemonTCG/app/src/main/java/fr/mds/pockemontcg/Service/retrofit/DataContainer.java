package fr.mds.pockemontcg.Service.retrofit;

import com.google.gson.annotations.SerializedName;

import java.util.List;

import fr.mds.pockemontcg.Model.Card;

public class DataContainer {

    @SerializedName("cards")
    private List<Card> cards;

    public DataContainer() {
    }

    public DataContainer(List<Card> cards) {
        this.cards = cards;
    }

    public List<Card> getCards() {
        return cards;
    }

    public void setCards(List<Card> cards) {
        this.cards = cards;
    }

    @Override
    public String toString() {
        return "DataContainer{" +
                "cards=" + cards +
                '}';
    }
}
