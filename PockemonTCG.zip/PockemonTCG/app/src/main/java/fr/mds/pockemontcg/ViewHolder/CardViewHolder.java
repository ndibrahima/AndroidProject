package fr.mds.pockemontcg.ViewHolder;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import fr.mds.pockemontcg.R;

public class CardViewHolder extends RecyclerView.ViewHolder {

    private TextView tv_item_card_name;
    private ImageView iv_item_card_image;

    public CardViewHolder(@NonNull View itemView) {
        super(itemView);

        tv_item_card_name = itemView.findViewById(R.id.tv_item_card_name);
        iv_item_card_image = itemView.findViewById(R.id.iv_item_card_image);
    }

    public TextView getTv_item_card_name() {
        return  tv_item_card_name;
    }

    //public ImageView getTv_item_card_image() {

    // }
}
